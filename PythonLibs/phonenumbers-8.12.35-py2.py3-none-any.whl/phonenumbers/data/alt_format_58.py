"""Auto-generated file, do not edit by hand. 58 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_58 = [NumberFormat(pattern='(\\d{3})(\\d{3})(\\d{4})', format='\\1 \\2 \\3')]
